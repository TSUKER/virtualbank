﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebLibrary;
using VirtualBank.Data.Entities;
using System.Data.Linq;

namespace WebRoot
{
    public partial class BillEditor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PaymentType.DataSource = Utility.TransactionTypes;
                PaymentType.DataTextField = "Key";
                PaymentType.DataValueField = "Value";
                PaymentType.DataBind();

                var payeeList = from p in Master.DataContext.Accounts
                                select p;

                Payees.DataSource = payeeList;
                Payees.DataTextField = "Description";
                Payees.DataValueField = "ID";
                Payees.DataBind();
            }
        }

        protected void AddPayee_Click(object sender, ImageClickEventArgs e)
        {
            NewPayee_PopupExtender.Show();
        }

        protected void SavePayee_Click(object sender, EventArgs e)
        {
            /*
            Account acct = new Account();
            acct.Description = PayeeDescription.Text;
            acct.Website = PayeeWebsite.Text;
            

            Master.DataContext.Payees.InsertOnSubmit(p);
            Master.DataContext.SubmitChanges();

            PayeeDescription.Text = String.Empty;
            PayeeName.Text = String.Empty;
            PayeeWebsite.Text = String.Empty;
            NewPayee_AjaxPanel.Update();

            var payeeList = from pl in Master.DataContext.Payees
                            select pl;

            Payees.Items.Clear();
            Payees.DataSource = payeeList;
            Payees.DataTextField = "PayeeName";
            Payees.DataValueField = "ID";
            Payees.DataBind();

            NewPayee_PopupExtender.Hide();
            */
        }

        protected void SaveButton_Click(object sender, EventArgs e)
        {
            Bill newBill = new Bill();
            newBill.AccountID = int.Parse(Payees.SelectedValue);
            newBill.AmountDue = decimal.Parse(AmountDue.Text);
            newBill.DueDate = DateTime.Parse(DueDate.Text);
            newBill.Description = Description.Text;
            newBill.Frequency = 12;

            Master.DataContext.Bills.InsertOnSubmit(newBill);
            Master.DataContext.SubmitChanges();
        }
    }
}