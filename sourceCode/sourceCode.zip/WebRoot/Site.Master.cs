﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VirtualBank.Data;

namespace WebRoot
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public VirtualBankDataContext DataContext
        {
            get
            {
                if (this._dataContext == null)
                    this._dataContext = new VirtualBankDataContext();

                return this._dataContext;
            }
        }
        private VirtualBankDataContext _dataContext;
    }
}
