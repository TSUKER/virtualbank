﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VirtualBank.Data;

namespace WebRoot
{
    public partial class SystemSetup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ResetButton_Click(object sender, EventArgs e)
        {
            //using (VirtualBankDataContext db = new VirtualBankDataContext())
            //{
                //db.Payees.DeleteAllOnSubmit(db.Payees);
                //db.DebtAccounts.DeleteAllOnSubmit(db.DebtAccounts);
                //db.Payments.DeleteAllOnSubmit(db.Payments);
                //db.PaymentAccounts.DeleteAllOnSubmit(db.PaymentAccounts);
                //db.Transactions.DeleteAllOnSubmit(db.Transactions);
                
                //db.SubmitChanges();
            //}
        }
    }
}