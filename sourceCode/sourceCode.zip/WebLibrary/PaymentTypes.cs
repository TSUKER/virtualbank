﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WebLibrary
{
    public enum TransactionTypes : byte
    {
        [Description("Auto-Debit")]
        AutoDebit = 0,
        [Description("Manual")]
        ManualPayment = 1,
        [Description("Outside Source")]
        OutsideSource = 2,
        [Description("Cash")]
        Cash = 3
    }
}
