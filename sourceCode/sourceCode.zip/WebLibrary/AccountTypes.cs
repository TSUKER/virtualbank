﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WebLibrary
{
    public enum AccountTypes : byte
    {
        [Description("Checking")]
        Checking = 0,
        [Description("Savings")]
        Savings = 1,
        [Description("Credit Card")]
        CreditCard = 2,
        [Description("Student Loan")]
        StudentLoan = 3,
        [Description("Private Loan")]
        PrivateLoan = 4,
        [Description("Collections Agency")]
        Collections = 5,
        [Description("Utility")]
        Utility = 6,
        [Description("Mortgage")]
        Mortgage = 7
    }
}
